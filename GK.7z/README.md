INSTRUKCJA OBSŁUGI PROGRAMU "POLYGON EDITOR"

Prawy przycisk myszy:

-Pojedyncze kliknięcie PPM zaznacza wierzchołek wielokąta lub
środek okręgu, kliknięcie PPM na znacznik relacji usuwa ją,
kliknięcie w biały obszar odznacza zaznaczone punkty

-Podwójne kliknięcie PPM rysuje punkt będący środkiem okręgu,
ponowne podwójne kliknięcie wyznacza promień okręgu

-Przytrzymanie PPM na zaznaczonym środku okręgu i przeciąganie
w górę/dół zwiększa/zmniejsza promień okręgu

-Przytrzymanie PPM na jednym z zaznaczonych wierzchołków na
wielokąta przesuwa go

Lewy przycisk myszy:

-Przytrzymanie LPM i przeciąganie zaznaczonego wierzchołka lub
środka okręgu pozwala przesunąć okrąg lub wybrany wierzchołek

-Przytrzymanie LPM i przeciągnięcie zaznaczonego wierzchołka
(przy dwóch zaznaczonych wierzchołkach) przesuwa krawędź

-Podwójne kliknięcie LPM włącza tryb rysowania wielokąta,
następne wierzchołki dodawane są kolejnymi podwójnymi
kliknięciami, rysowanie kończy klawisz Spacji

Klawisze:

-Po zaznzaczeniu dwóch wierzchołków Shift dodaje wierzchołek
na środku wybranej krawędzi

-Po zaznaczeniu wierzchołka Del usuwa go, po zaznaczeniu środka
okręgu Del usuwa okrąg, po zaznaczeniu krawędzi Del usuwa cały
wielokąt

-Spacja kończy rysowanie wielokąta

Przyciski: 

-Przyciski po prawej stronie podświetlają się po zaznaczeniu
środka okręgu lub 2 wierzchołków wielokąta i informują o tym,
jakie relacje można dodać

-W celu ustalenia konkretnej długości promienia okręgu lub krawędzi
należy zaznaczyć środek okręgu lub krawędź (zaznaczanie - PPM).
Następnie należy wybrać "Get length/radius". Wyświetlona zostanie
wtedy aktualna długość. Użytkownik może teraz wpisać własną i 
wybrać "Set", wtedy długość zostanie ustalona na wpisaną.
Podanie wartości ujemnej lub ciągu innych niż liczby znaków nie 
pozwoli zmodyfikować długości.

Założenia:

-Żeby wprowadzić relację równej długości dla sąsiadujących krawędzi
wspólny wierzchołek musi zostać zaznaczony jako 2 i 4 w kolejności

-Nie można usunąć wierzchołka, jeśli wielokąt ma tylko 3 wierzchołki

-Okrąg nie może mieć jednocześnie ustalonego promienia i zablokowanego
środka

-Relacje traktują wielokąt nadrzędnie w stosunku do okręgu, kiedy na 
krawędź i okrąg nałożona jest relacja styczności

-Jeśli krawędź ma już relację, to dodanie kolejnej nie zostanie wykonane

-Jeśli przy przesuwaniu wierzchołek "ucieka" od kursora, oznacza
to, że zachodziłoby naruszenie relacji, na co wielokąt nie pozwala

-Relacje przechowywane są na liście, podczas każdej wprowadzanej
w modelu zmainy lista jest przeglądana i zależności są poprawiane.
Każda relacja zwraca true, jeśli coś musiało zostać poprawione lub
false, jeśli nie było takiej konieczności. Relacje są poprawiane do
momentu, gdy żadna z nich nie wywołała zmiany w modelu lub wykonano 
10 cykli, podczas których była przeglądana lista relacji

-Relacje zostały zaimplementowane w oparciu o geometrię analityczną

Kilka słów na koniec: Bardzo starałam się, żeby program był odporny na
próby rysowania poza obszarem bitmapy i by nie powodowało to wyrzucania
wyjątków kończących program. Do implementacji relacji używałam głównie
wzorów na proste równoległe i prostopadłe w postaci kierunkowej, oddzielnie
były rozpatrywane przypadki dla prostych pionowych/poziomych. Mam nadzieję, 
że korzystanie z programu jest w miarę intuicyjne i spełnia on wszystkie
podane w treści zadania wymagania.


