﻿using Newtonsoft.Json;
using Rasterization.Relations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rasterization
{
    public partial class App : Form
    {
        List<Shape> shapes;
        Shape selectedShape = null;
        MyPoint selectedPoint1 = new MyPoint(-1,-1);
        MyPoint selectedPoint2 = new MyPoint(-1, -1);
        bool isDrawing = false;
        bool isDragging = false;
        bool polygonMoved = false;
        bool vertexMoved = false;
        Point movePoint = new Point(-1, -1);
        public Bitmap bitmap;
        Graphics g;
        bool parallel = false;
        bool equal = false;
        bool tangent = false;
        MyPoint selectedPoint3 = new MyPoint(-1, -1);
        MyPoint selectedPoint4 = new MyPoint(-1, -1);
        List<Relation> relations = new List<Relation>();
        public int[] counter = new int[6] { 0, 0, 0, 0, 0, 0};
        public bool antyaliasing = false;
        public App()
        {
            InitializeComponent();
            bitmap = new Bitmap(800, 800);
            MyCanvas.Image = bitmap;
            g = Graphics.FromImage(bitmap);
            Polygon p1 = new Polygon(new List<MyPoint> { new MyPoint(275, 440), new MyPoint(300, 609), new MyPoint(395, 715), new MyPoint(493, 500), new MyPoint(550, 200) });
            Polygon p2 = new Polygon(new List<MyPoint> { new MyPoint(100,300), new MyPoint(200,200), new MyPoint(300,300), new MyPoint(200,100) });
            Circle c1 = new Circle(new MyPoint(126, 466), 100);
            Circle c2 = new Circle(new MyPoint(640, 329), 55);

            //Wielokąt z prostopadłością - dodatkowo
            //Polygon p3 = new Polygon(new List<MyPoint> { new MyPoint(50, 50), new MyPoint(100, 50), new MyPoint(120, 80), new MyPoint(60, 130), new MyPoint(55, 125) });
            //relations.Add(new PerpendicularEdgesRelation(p3, p3, p3.points[0], p3.points[1], p3.points[2], p3.points[3], counter[0]));

            relations.Add(new ParallelEdgesRelation(p1, p1, p1.points[1], p1.points[2], p1.points[3], p1.points[4], counter[5]++));
            relations.Add(new EqualLengthRelation(p2, p2, p2.points[0], p2.points[1], p2.points[2], p2.points[3], counter[0]++));
            relations.Add(new FixedLengthRelation(p2, p2.points[1], p2.points[2], 60, counter[4]++));
            relations.Add(new TangentRelation(c2, p1.points[2], p1.points[3], counter[2]++));
            relations.Add(new FixedCenterRelation(c2, c2.center[0], counter[1]++));
            relations.Add(new FixedRatioRelation(c1, counter[3]++));
            relations.Add(new FixedLengthRelation(p1, p1.points[0], p1.points[1], 170, counter[4]++));
            shapes = new List<Shape> { p1, c1, p2, c2};
            DrawAll();
        }

        ///------------------------------DRAWING-----------------------------------///
        public void Clear()
        {
            selectedShape = null;
            selectedPoint1 = new MyPoint(-1, -1);
            selectedPoint2 = new MyPoint(-1, -1);
            selectedPoint3 = new MyPoint(-1, -1);
            selectedPoint4 = new MyPoint(-1, -1);
            parallel = false;
            equal = false;
            tangent = false;
            ParallelEdges.BackColor = Color.MistyRose;
            EqualEdges.BackColor = Color.MistyRose;
            TangentLine.BackColor = Color.MistyRose;
            textBox1.Clear();
        }

        public int ForceChanges()
        {
            int count = 0;
            foreach (var relation in relations)
            {
                if (relation.ForceUpdate())
                    count++;
            }
            return count;
        }

        public void RefreshDrawing()
        {
            for(int i=0; i<10; i++)
            {
                if (ForceChanges() == 0) return;
            }
        }
        public void DrawAll(bool clear = true, bool rel = true)
        {
            g.Clear(Color.White);
            if (clear) Clear();
            if (rel) RefreshDrawing();
            foreach (var shape in shapes)
                shape.DrawShapes(ref bitmap, antyaliasing);
            if (isDrawing)
            {
                for(int i=0; i < shapes[shapes.Count - 1].Points.Count; i++)
                {
                    shapes[shapes.Count - 1].SelectPoint(i, ref bitmap, ref MyCanvas);
                }
            }
            DrawColoredLines();
            ButtonsDisabled();
            MyCanvas.Invalidate();
        }

        private bool HasRelation(MyPoint p1, MyPoint p2)
        {
            foreach (var relation in relations)
            {
                if (relation is ParallelEdgesRelation pr)
                {
                    if (pr.points[0] == p1 && pr.points[1] == p2) return true;
                    if (pr.points[1] == p1 && pr.points[0] == p2) return true;
                    if (pr.points[2] == p1 && pr.points[3] == p2) return true;
                    if (pr.points[3] == p1 && pr.points[2] == p2) return true;
                }                                                       
                else if (relation is EqualLengthRelation er)             
                {                                                        
                    if (er.points[0] == p1 && er.points[1] == p2) return true;
                    if (er.points[1] == p1 && er.points[0] == p2) return true;
                    if (er.points[2] == p1 && er.points[3] == p2) return true;
                    if (er.points[3] == p1 && er.points[2] == p2) return true;
                }
                else if (relation is TangentRelation tr)
                {
                    if (tr.points.Contains(p1) && tr.points.Contains(p2)) return true;
                }
                else if (relation is FixedLengthRelation lr)
                {
                    if (lr.points.Contains(p1) && lr.points.Contains(p2)) return true;
                }
            }
            return false;
        }

        private bool HasRelation(MyPoint p1)
        {
            foreach (var relation in relations)
            {
                if (relation is TangentRelation tr)
                {
                    if (tr.points.Contains(p1)) return true;
                }
                else if (relation is FixedCenterRelation fcr)
                {
                    if (fcr.points.Contains(p1)) return true;
                }
                else if (relation is FixedRatioRelation frr)
                {
                    if (frr.points.Contains(p1)) return true;
                }
            }
            return false;
        }
        
        public bool FindPoint(int x, int y)
        {
            for (int i = -5; i <= 5; i++)
            {
                for (int j = -5; j <= 5; j++)
                {
                    if (selectedShape.HasPoint(x + i, y + j) > -1) 
                        return true;
                }
            }
            return false;
        }

        ///------------------------------MOUSE-----------------------------------///
        private void MyCanvas_Click(object sender, EventArgs e)
        {
            if (((MouseEventArgs)e).Button == MouseButtons.Right)
            {
                foreach (var relation in relations)
                {
                    foreach (var rectangle in relation.Rectangle)
                    {
                        if (rectangle.Contains(new Point(((MouseEventArgs)e).X, ((MouseEventArgs)e).Y)))
                        {
                            if (relation is FixedCenterRelation fcr) fcr.c.isCenterLocked = false;
                            if (relation is FixedRatioRelation frr) frr.C.isLocked = false;
                            relations.Remove(relation);
                            DrawAll();
                            return;
                        }
                    }
                }
                for (int i = -5; i <= 5; i++)
                {
                    for (int j = -5; j <= 5; j++)
                    {
                        foreach (var shape in shapes)
                        {
                            int index = shape.HasPoint(((MouseEventArgs)e).X + i, ((MouseEventArgs)e).Y + j);
                            if (index > -1)
                            {
                                if (parallel && new MyPoint(((MouseEventArgs)e).X + i, ((MouseEventArgs)e).Y + j) != selectedPoint1 && new MyPoint(((MouseEventArgs)e).X + i, ((MouseEventArgs)e).Y + j) != selectedPoint2)
                                {
                                    Polygon p = (Polygon)shape;
                                    ParallelClick(p, index);
                                    return;
                                }
                                if (equal && new MyPoint(((MouseEventArgs)e).X + i, ((MouseEventArgs)e).Y + j) != selectedPoint1)
                                {
                                    Polygon p = (Polygon)shape;
                                    EqualClick(p, index);
                                    return;
                                }
                                if (tangent && shape is Circle c)
                                {
                                    selectedShape = shape;
                                    TangentClick();
                                    return;
                                }
                                selectedShape = shape;
                                if (selectedPoint1 == new MyPoint(-1, -1))
                                {
                                    selectedPoint1 = selectedShape.Points[index];
                                    if (selectedShape is Circle) ButtonsActiveC();
                                }
                                else if (selectedPoint2 == new MyPoint(-1, -1))
                                {
                                    if (!selectedShape.CanSelect(index, selectedPoint1))
                                    {
                                        DrawAll(true, false);
                                        selectedShape = shape;
                                        selectedPoint1 = selectedShape.Points[index];
                                    }
                                    else
                                    {
                                        selectedPoint2 = selectedShape.Points[index];
                                        ButtonsActiveP();
                                    }
                                }
                                else if (selectedPoint2 != new MyPoint(-1, -1))
                                {
                                    DrawAll(true, false);
                                    selectedShape = shape;
                                    selectedPoint1 = selectedShape.Points[index];
                                }
                                selectedShape.SelectPoint(index, ref bitmap, ref MyCanvas);
                                if (selectedShape is Circle) ButtonsActiveC();
                                if (selectedShape is Polygon && selectedPoint2 != new MyPoint(-1, -1)) ButtonsActiveP();
                                return;
                            }
                        }
                    }
                }
                DrawAll();
            }
        }

        private void MyCanvas_DoubleClick(object sender, EventArgs e)
        {
            MyPoint coordinates = new MyPoint(MyCanvas.PointToClient(Cursor.Position).X, MyCanvas.PointToClient(Cursor.Position).Y);
            if (((MouseEventArgs)e).Button == MouseButtons.Left)
            {
                if (!isDrawing)
                {
                    isDrawing = true;
                    shapes.Add(new Polygon(coordinates));
                }
                else
                {
                    shapes[shapes.Count - 1].Points.Add(coordinates);
                }
            }
            else
            {
                if (!isDrawing)
                {
                    isDrawing = true;
                    shapes.Add(new Circle(coordinates));
                }
                else
                {
                    Circle circle = (Circle)shapes[shapes.Count - 1];
                    circle.r = (int)Math.Sqrt(Math.Pow(coordinates.X - circle.center[0].X, 2) + Math.Pow(coordinates.Y - circle.center[0].Y, 2));
                    isDrawing = false;
                }
            }
            DrawAll();
        }
        private void MyCanvas_MouseDown(object sender, MouseEventArgs e)
        {
            if (selectedShape != null && FindPoint(e.X, e.Y))
            {
                movePoint = new Point(e.X, e.Y);
                isDragging = true;
            }
        }

        private void MyCanvas_MouseUp(object sender, MouseEventArgs e)
        {
            if(isDragging)
            {
                isDragging = false;
                movePoint = new Point(-1, -1);
                if(polygonMoved)
                {
                    polygonMoved = false;
                    DrawAll();
                    return;
                }
                if(vertexMoved)
                {
                    selectedPoint1 = new MyPoint(-1, -1);
                    selectedPoint2 = new MyPoint(-1, -1);
                    vertexMoved = false;
                }
            }
        }

        private void MyCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            Point coordinates = e.Location;
            int x = e.X - movePoint.X;
            int y = e.Y - movePoint.Y;
            movePoint = coordinates;
            if (isDragging && e.Button == MouseButtons.Left && selectedPoint2.X!= -1 && selectedPoint2.Y!=-1)
            {
                Polygon p = (Polygon)selectedShape;
                (selectedPoint1, selectedPoint2) = p.MoveTwoPoints(x, y, selectedPoint1, selectedPoint2);
                DrawAll(false);
            }
            else if (isDragging && e.Button == MouseButtons.Left)
            {
                selectedPoint1 = selectedShape.MoveOnePoint(x, y, selectedPoint1);
                DrawAll(false);
                vertexMoved = true;
            }
            else if(e.Button == MouseButtons.Right && selectedShape != null && selectedShape is Circle)
            {
                Circle circle = selectedShape as Circle;
                circle.ChangeRadius(circle.r - y);
                DrawAll(false);
            }
            else if (e.Button == MouseButtons.Right && selectedShape != null && selectedShape is Polygon)
            {
                Polygon polygon = selectedShape as Polygon;
                polygon.MovePoints(x, y);
                DrawAll(false);
                polygonMoved = true;
            }
        }

        ///------------------------------KEYBOARD-----------------------------------///
        private void App_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                isDrawing = false;
                if (shapes[shapes.Count - 1] is Polygon p)
                {
                    if (p.points.Count <= 2)
                    {
                        shapes.RemoveAt(shapes.Count - 1);
                    }
                    DrawAll();
                }
            }
            if (e.KeyCode == Keys.ShiftKey && selectedShape != null && selectedPoint2 != new MyPoint(-1, -1) && !tangent && !equal && !parallel)
            {
                isDrawing = false;
                Polygon p = (Polygon)selectedShape;
                relations.RemoveAll(relation => relation.Points.Contains(selectedPoint1)&& relation.Points.Contains(selectedPoint2)&&HasRelation(selectedPoint1,selectedPoint2));
                p.AddPoint(selectedPoint1, selectedPoint2);
                DrawAll();
            }
            if (e.KeyCode == Keys.Delete && isDrawing)
            {
                isDrawing = false;
                shapes.RemoveAt(shapes.Count - 1);
                DrawAll();
            }
            if (e.KeyCode == Keys.Delete && selectedShape != null && selectedPoint2 == new MyPoint(-1, -1) && selectedShape is Polygon)
            {
                isDrawing = false;
                Polygon p = (Polygon)selectedShape;
                relations.RemoveAll(relation => relation.Points.Contains(selectedPoint1));
                p.DeletePoint(selectedPoint1);
                DrawAll();
            }
            if (e.KeyCode == Keys.Delete && selectedShape != null && selectedPoint2 != new MyPoint(-1, -1) && selectedShape is Polygon)
            {
                isDrawing = false;
                Polygon p = (Polygon)selectedShape;
                foreach(var point in p.points)
                    relations.RemoveAll(relation => relation.Points.Contains(point));
                shapes.Remove(p);
                DrawAll();
            }
            if (e.KeyCode == Keys.Delete && selectedShape != null && selectedShape is Circle)
            {
                isDrawing = false;
                Circle c = (Circle)selectedShape;
                relations.RemoveAll(relation => relation.Points.Contains(c.Points[0]));
                shapes.Remove(c);
                DrawAll();
            }
            if(e.KeyCode == Keys.ControlKey)//Zapisywanie bitmapy jako .jpeg
            {
                SaveFileDialog dialog = new SaveFileDialog();
                dialog.DefaultExt = "jpeg";
                dialog.Filter = "Image Files (*.jpeg)|*.jpeg";
                dialog.AddExtension = true;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    bitmap.Save(dialog.FileName, ImageFormat.Jpeg);
                }
            }
        }

        ///------------------------------ADDING RELATIONS-----------------------------------///
        private void ParallelClick(Polygon p, int index)
        {
            if (selectedPoint3 == new MyPoint(-1, -1))
            {
                selectedPoint3 = p.points[index];
                p.SelectPoint(index, ref bitmap, ref MyCanvas);
            }
            else if (selectedPoint4 == new MyPoint(-1, -1))
            {
                selectedPoint4 = p.points[index];
                p.SelectPoint(index, ref bitmap, ref MyCanvas);
                if (!HasRelation(selectedPoint1, selectedPoint2) && !HasRelation(selectedPoint3, p.points[index]))
                {
                    relations.Add(new ParallelEdgesRelation((Polygon)selectedShape, p, selectedPoint1, selectedPoint2, selectedPoint3, p.points[index], counter[5]++));
                }
                DrawAll();
                parallel = false;
            }
            else
            {
                parallel = false;
                DrawAll();
            }
        }

        private void EqualClick(Polygon p, int index)
        {
            if (selectedPoint3 == new MyPoint(-1, -1))
            {
                selectedPoint3 = p.points[index];
                p.SelectPoint(index, ref bitmap, ref MyCanvas);
            }
            else if (selectedPoint4 == new MyPoint(-1, -1))
            {
                selectedPoint4 = p.points[index];
                p.SelectPoint(index, ref bitmap, ref MyCanvas);
                if (!HasRelation(selectedPoint1, selectedPoint2) && !HasRelation(selectedPoint3, p.points[index]))
                {
                    relations.Add(new EqualLengthRelation((Polygon)selectedShape, p, selectedPoint1, selectedPoint2, selectedPoint3, p.points[index], counter[0]++));
                }
                DrawAll();
                equal = false;
            }
            else
            {
                equal = false;
                DrawAll();
            }
        }

        private void TangentClick()
        {
            Circle c = (Circle)selectedShape;
            if (!HasRelation(selectedPoint1, selectedPoint2))
            {
                relations.Add(new TangentRelation(c, selectedPoint1, selectedPoint2, counter[2]++));
            }
            DrawAll();
            tangent = false;
        }
        private void ParallelEdges_Click(object sender, EventArgs e)
        {
            if (selectedShape == null || selectedPoint2 == new MyPoint(-1, -1)) return;
            parallel = true;
            ButtonsDisabled();
            ParallelEdges.BackColor = Color.Salmon;
        }

        private void Get_Click(object sender, EventArgs e)
        {
            ButtonsDisabled();
            if (selectedShape != null && selectedShape is Circle)
            {
                Circle c = (Circle)selectedShape;
                textBox1.Text = ((int)c.r).ToString();
                Set.BackColor = Color.MistyRose;
            }
            else if (selectedShape != null && selectedPoint2 != new MyPoint(-1, -1))
            {
                Polygon p = (Polygon)selectedShape;
                textBox1.Text = ((int)(p.GetEdgeLength(selectedPoint1, selectedPoint2))).ToString();
                Set.BackColor = Color.MistyRose;
            }
        }

        private void Set_Click(object sender, EventArgs e)
        {
            ButtonsDisabled();
            if (selectedShape != null && selectedShape is Circle)
            {
                Circle c = (Circle)selectedShape;
                foreach(var relation in relations)
                {
                    if (relation is FixedCenterRelation fcr && fcr.points[0] == c.center[0])
                    {
                        DrawAll();
                        return;
                    }

                }
                double r;
                if(!Double.TryParse(textBox1.Text,out r) || r <= 0)
                {
                    DrawAll();
                    return;
                }
                c.r = (int)r;
                relations.Add(new FixedRatioRelation(c, counter[3]++));
                DrawAll();
            }
            else if (selectedShape != null && selectedPoint2 != new MyPoint(-1, -1))
            {
                Polygon p = (Polygon)selectedShape;
                double r;
                if (!Double.TryParse(textBox1.Text, out r) || r <= 0)
                {
                    DrawAll();
                    return;
                }
                relations.Add(new FixedLengthRelation(p, selectedPoint1, selectedPoint2, r, counter[4]++));
                DrawAll();
            }
        }

        private void EqualEdges_Click(object sender, EventArgs e)
        {
            if (selectedShape == null || selectedPoint2 == new MyPoint(-1, -1)) return;
            equal = true;
            ButtonsDisabled();
            EqualEdges.BackColor = Color.Salmon;
        }

        private void SetCenter_Click(object sender, EventArgs e)
        {
            if (selectedShape != null && selectedShape is Circle)
            {
                Circle c = (Circle)selectedShape;
                foreach (var relation in relations)
                {
                    if (relation is FixedRatioRelation frr && frr.points[0] == c.center[0])
                    {
                        DrawAll();
                        return;
                    }

                }
                relations.Add(new FixedCenterRelation(c, c.center[0], counter[1]++));
                c.isCenterLocked = true;
                DrawAll();
            }
        }

        private void TangentLine_Click(object sender, EventArgs e)
        {
            if (selectedShape != null && selectedPoint2 != new MyPoint(-1, -1))
            {
                tangent = true;
                ButtonsDisabled();
                TangentLine.BackColor = Color.Salmon;
            }
        }

        private void AntyaliasingButton_Click(object sender, EventArgs e)
        {
            antyaliasing = !antyaliasing;
            if (antyaliasing)
            {
                AntyaliasingButton.Text = "Antialiasing is on";
                AntyaliasingButton.BackColor = Color.Salmon;
            }
            else
            {
                AntyaliasingButton.Text = "Antialiasing is off";
                AntyaliasingButton.BackColor = Color.MistyRose;
            }
            DrawAll();
        }
    }
}
