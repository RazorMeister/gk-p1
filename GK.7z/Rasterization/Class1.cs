﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Rasterization
{
    public partial class App : Form
    {
        private void ButtonsDisabled()
        {
            ParallelEdges.BackColor = Color.Gainsboro;
            EqualEdges.BackColor = Color.Gainsboro;
            TangentLine.BackColor = Color.Gainsboro;
            Set.BackColor = Color.Gainsboro;
            SetCenter.BackColor = Color.Gainsboro;
            SetEdges.BackColor = Color.Gainsboro;
            if (!antyaliasing)
                AntyaliasingButton.BackColor = Color.MistyRose;
        }

        private void ButtonsActiveP()
        {
            ParallelEdges.BackColor = Color.MistyRose;
            EqualEdges.BackColor = Color.MistyRose;
            TangentLine.BackColor = Color.MistyRose;
            SetEdges.BackColor = Color.MistyRose;
        }

        private void ButtonsActiveC()
        {
            SetCenter.BackColor = Color.MistyRose;
            SetEdges.BackColor = Color.MistyRose;
        }
        private void DrawColoredLines()
        {
            String drawString = "";
            Font drawFont = new Font("Arial", 12);
            SolidBrush drawBrush = new SolidBrush(Color.Black);
            StringFormat drawFormat = new StringFormat();
            drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;

            foreach (var relation in relations)
            {
                if (relation is ParallelEdgesRelation pr)
                {
                    drawString = "P" + pr.id.ToString();
                    g.DrawRectangle(new Pen(Color.DarkMagenta), pr.rectangle[0]);
                    g.FillRectangle(new SolidBrush(Color.DarkMagenta), pr.rectangle[0]);
                    g.DrawRectangle(new Pen(Color.DarkMagenta), pr.rectangle[1]);
                    g.FillRectangle(new SolidBrush(Color.DarkMagenta), pr.rectangle[1]);
                    g.DrawString(drawString, drawFont, drawBrush, pr.rectangle[0].X - 5, pr.rectangle[0].Y - 5, drawFormat);
                    g.DrawString(drawString, drawFont, drawBrush, pr.rectangle[1].X - 5, pr.rectangle[1].Y - 5, drawFormat);
                }
                else if (relation is EqualLengthRelation er)
                {
                    drawString = "E" + er.id.ToString();
                    g.DrawRectangle(new Pen(Color.Indigo), er.rectangle[0]);
                    g.FillRectangle(new SolidBrush(Color.Indigo), er.rectangle[0]);
                    g.DrawRectangle(new Pen(Color.Indigo), er.rectangle[1]);
                    g.FillRectangle(new SolidBrush(Color.Indigo), er.rectangle[1]);
                    g.DrawString(drawString, drawFont, drawBrush, er.rectangle[0].X - 5, er.rectangle[0].Y - 5, drawFormat);
                    g.DrawString(drawString, drawFont, drawBrush, er.rectangle[1].X - 5, er.rectangle[1].Y - 5, drawFormat);
                }
                else if (relation is TangentRelation tr)
                {
                    drawString = "T" + tr.id.ToString();
                    g.DrawRectangle(new Pen(Color.DarkViolet), tr.rectangle[0]);
                    g.FillRectangle(new SolidBrush(Color.DarkViolet), tr.rectangle[0]);
                    g.DrawRectangle(new Pen(Color.DarkViolet), tr.rectangle[1]);
                    g.FillRectangle(new SolidBrush(Color.DarkViolet), tr.rectangle[1]);
                    g.DrawString(drawString, drawFont, drawBrush, tr.rectangle[0].X - 5, tr.rectangle[0].Y - 5, drawFormat);
                    g.DrawString(drawString, drawFont, drawBrush, tr.rectangle[1].X - 5, tr.rectangle[1].Y - 5, drawFormat);
                }
                else if (relation is FixedLengthRelation lr)
                {
                    drawString = "L" + lr.id.ToString();
                    g.DrawRectangle(new Pen(Color.Thistle), lr.rectangle[0]);
                    g.FillRectangle(new SolidBrush(Color.Thistle), lr.rectangle[0]);
                    g.DrawString(drawString, drawFont, drawBrush, lr.rectangle[0].X - 5, lr.rectangle[0].Y - 5, drawFormat);
                }
                else if (relation is FixedRatioRelation frr)
                {
                    drawString = "R" + frr.id.ToString();
                    g.DrawRectangle(new Pen(Color.PaleVioletRed, 1), frr.rectangle[0]);
                    g.FillRectangle(new SolidBrush(Color.PaleVioletRed), frr.rectangle[0]);
                    g.DrawString(drawString, drawFont, drawBrush, frr.rectangle[0].X - 5, frr.rectangle[0].Y - 5, drawFormat);
                }
                else if (relation is FixedCenterRelation fcr)
                {
                    drawString = "C" + fcr.id.ToString();
                    g.DrawRectangle(new Pen(Color.Violet, 1), fcr.rectangle[0]);
                    g.FillRectangle(new SolidBrush(Color.Violet), fcr.rectangle[0]);
                    g.DrawString(drawString, drawFont, drawBrush, fcr.rectangle[0].X - 5, fcr.rectangle[0].Y - 5, drawFormat);
                }
            }
        }
    }
}
