﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Rasterization
{
    public class MyPoint
    {
        public int X;
        public int Y;
        public MyPoint(int x, int y)
        {
            X = x;
            Y = y;
        }
        public static bool operator ==(MyPoint a, MyPoint b)
        {
            if (a.X == b.X && a.Y == b.Y) return true;
            return false;
        }

        public static bool operator !=(MyPoint a, MyPoint b)
        {
            return!(a == b);
        }
    }
}
