﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Rasterization
{
    public interface Shape
    {
        public int HasPoint(int x, int y);
        public bool CanBeRemoved();
        public void DrawShapes(ref Bitmap bitmap, bool antyaliasing = false);
        public void SelectPoint(int index, ref Bitmap bitmap, ref PictureBox app);
        public bool CanSelect(int index, MyPoint p);
        public MyPoint MoveOnePoint(int x, int y, MyPoint p);
        public List<MyPoint> Points { get; }

    }
}
