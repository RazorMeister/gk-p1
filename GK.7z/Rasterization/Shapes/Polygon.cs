﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Rasterization
{
    class Polygon : Shape
    {
        public List<MyPoint> points;
        public MyPoint lastMoved = new MyPoint(-1, -1);
        public List<MyPoint> Points
        {
            get { return points; }
        }
        public Polygon(List<MyPoint> Points)
        {
            points = Points;
        }

        public Polygon(MyPoint p)
        {
            points = new List<MyPoint> { p };
        }

        public void DeletePoint(MyPoint p)
        {
            int index = HasPoint(p.X, p.Y);
            if (index < 0 || CanBeRemoved()) return;
            points.RemoveAt(index);
        }

        public void AddPoint(MyPoint p1, MyPoint p2)
        {
            int prev = HasPoint(p1.X, p1.Y);
            int next = HasPoint(p2.X, p2.Y);
            if (prev < 0 || next < 0) return;
            if (prev == 0 && next == points.Count - 1) prev = next;
            if (prev > next && prev < points.Count - 1) prev = next;
            int x = (p1.X + p2.X) / 2;
            int y = (p1.Y + p2.Y) / 2;
            points.Insert(prev + 1, new MyPoint(x, y));
        }

        public int HasPoint(int x, int y)
        {
            for (int i = 0; i < points.Count; i++)
            {
                if (points[i].X == x && points[i].Y == y) return i;
            }
            return -1;
        }

        public bool CanBeRemoved()
        {
            if (points.Count <= 3) return true;
            return false;
        }

        public void MovePoints(int x, int y)
        {
            for (int i = 0; i < points.Count; i++)
            {
                points[i].X += x;
                points[i].Y += y;
            }
        }

        public MyPoint MoveOnePoint(int x, int y, MyPoint p)
        {
            int index = HasPoint(p.X, p.Y);
            if (index < 0) return new MyPoint(-1, -1);
            points[index].X += x;
            points[index].Y += y;
            return points[index];
        }

        public (MyPoint, MyPoint) MoveTwoPoints(int x, int y, MyPoint p, MyPoint r)
        {
            int index1 = HasPoint(p.X, p.Y);
            if (index1 < 0) return (new MyPoint(-1, -1), new MyPoint(-1, -1));
            points[index1].X += x;
            points[index1].Y += y;
            int index2 = HasPoint(r.X, r.Y);
            if (index2 < 0) return (new MyPoint(-1, -1), new MyPoint(-1, -1));
            points[index2].X += x;
            points[index2].Y += y;
            return (points[index1], points[index2]);
        }

        public void DrawShapes(ref Bitmap bitmap, bool antyaliasing = false)
        {
            Graphics g = Graphics.FromImage(bitmap);
            Pen p = new Pen(Color.Pink);
            SolidBrush sb = new SolidBrush(Color.Pink);
            if(antyaliasing)
            {
                for (int i = 0; i < points.Count; i++)
                {
                    int j = i == points.Count - 1 ? 0 : i + 1;
                    WuLine(points[i].X, points[i].Y, points[j].X, points[j].Y, ref bitmap);
                }
            }
            else
            {
                for (int i = 0; i < points.Count; i++)
                {
                    int j = i == points.Count - 1 ? 0 : i + 1;
                    DrawLine(points[i].X, points[i].Y, points[j].X, points[j].Y, ref bitmap);
                }
            }
            
            for (int i = 0; i < points.Count; i++)
            {
                if (points[i].X - 5 >= 0 && points[i].X - 5 < 800 && points[i].Y - 5 >= 0 && points[i].Y < 800)
                {
                    g.DrawEllipse(p, points[i].X - 5, points[i].Y - 5, 11, 11);
                    g.FillEllipse(sb, points[i].X - 5, points[i].Y - 5, 11, 11);
                }
            }
        }

        private void Swap(ref int x, ref int y)
        {
            int z = y;
            y = x;
            x = z;
        }
        private void DrawPoint(bool steep, int x, int y, float intensity, ref Bitmap bitmap)
        {
            int r = (int)(255 * (1.0 - intensity));
            if (r < 0 || r > 255) return;
            Color color = Color.FromArgb(r, r, r);
            if(x >=0 && x<800 && y>=0 && y<800)
                bitmap.SetPixel(steep ? y : x, steep ? x : y, color);
        }
        public void WuLine(int x0, int y0, int x1, int y1, ref Bitmap bitmap)
        {
            var steep = Math.Abs(y1 - y0) > Math.Abs(x1 - x0);
            if (steep)
            {
                Swap(ref x0, ref y0);
                Swap(ref x1, ref y1);
            }
            if (x0 > x1)
            {
                Swap(ref x0, ref x1);
                Swap(ref y0, ref y1);
            }

            DrawPoint(steep, x0, y0, 1, ref bitmap);
            DrawPoint(steep, x1, y1, 1, ref bitmap);
            float dx = x1 - x0;
            float dy = y1 - y0;
            float gradient = dy / dx;
            float y = y0 + gradient;
            for (var x = x0 + 1; x <= x1 - 1; x++)
            {
                DrawPoint(steep, x, (int)y, 1 - (y - (int)y), ref bitmap);
                DrawPoint(steep, x, (int)y + 1, y - (int)y, ref bitmap);
                y += gradient;
            }
        }

        public void DrawLine(int x0, int y0, int x1, int y1, ref Bitmap bitmap)
        {
            int dx = Math.Abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
            int dy = Math.Abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
            int err = (dx > dy ? dx : -dy) / 2, e2;
            for (; ; )
            {
                if (x0 >= 0 && y0 >= 0 && x0 < 800 && y0 < 800)
                    bitmap.SetPixel(x0, y0, Color.Black);
                if (x0 == x1 && y0 == y1) break;
                e2 = err;
                if (e2 > -dx) { err -= dy; x0 += sx; }
                if (e2 < dy) { err += dx; y0 += sy; }
            }
        }

        public void SelectPoint(int index, ref Bitmap bitmap, ref PictureBox app)
        {
            lastMoved = points[index];
            Graphics g = Graphics.FromImage(bitmap);
            Pen p = new Pen(Color.DeepPink);
            SolidBrush sb = new SolidBrush(Color.DeepPink);
            if (points[index].X - 5 >= 0 && points[index].X - 5 < 800 && points[index].Y - 5 >= 0 && points[index].Y < 800)
            {
                g.DrawEllipse(p, points[index].X - 5, points[index].Y - 5, 11, 11);
                g.FillEllipse(sb, points[index].X - 5, points[index].Y - 5, 11, 11);
            }
            app.Invalidate();
        }

        public bool CanSelect(int index, MyPoint p)
        {
            int prev = index - 1 == -1 ? points.Count - 1 : index - 1;
            int next = index + 1 == points.Count ? 0 : index + 1;
            if (points[prev] != p && points[next] != p) return false;
            return true;
        }

        public void SetParallel(MyPoint p1, MyPoint p2, MyPoint p3, MyPoint p4)
        {
            int i4 = points.IndexOf(p4);
            if (i4 < 0) return;
            if (p1.X == p2.X)
            {
                points[i4].X = p3.X;
                return;
            }
            if (p1.Y == p2.Y)
            {
                points[i4].Y = p3.Y;
                return;
            }
            int y12 = p2.Y - p1.Y;
            int x12 = p2.X - p1.X;
            double a34 = (double)y12 / (double)x12;
            double b34 = (double)p3.Y - a34 * (double)p3.X;
            double a44 = -1 / a34;
            double b44 = (double)p4.Y - a44 * (double)p4.X;
            int x4 = (int)((b44 - b34) / (a34 - a44));
            int y4 = (int)(a44 * (double)x4 + b44);
            points[i4].X = x4;
            points[i4].Y = y4;
        }

        public void SetPerpendicular(MyPoint p1, MyPoint p2, MyPoint p3, MyPoint p4)//Prostopadłość - zrobiłam dodatkowo
        {
            int i4 = points.IndexOf(p4);
            if (i4 < 0) return;
            if (p1.X == p2.X)
            {
                points[i4].Y = p3.Y;
                return;
            }
            if (p1.Y == p2.Y)
            {
                points[i4].X = p3.X;
                return;
            }
            int i3 = points.IndexOf(p3);
            int y12 = p2.Y - p1.Y;
            int x12 = p2.X - p1.X;
            double a34 = (double)y12 / (double)x12;
            double b34 = (double)p3.Y - a34 * (double)p3.X;
            double a44 = -1 / a34;
            double b44 = (double)p4.Y - a44 * (double)p4.X;
            int x4 = (int)((b44 - b34) / (a34 - a44));
            int y4 = (int)(a44 * (double)x4 + b44);
            points[i3].X = x4;
            points[i3].Y = y4;
        }

        public void SetPerpendicularShared(MyPoint p1, MyPoint p2, MyPoint p3)//Prostopadłość - zrobiłam dodatkowo
        {
            int i3 = points.IndexOf(p3);
            if (i3 < 0) return;
            if (p1.X == p2.X)
            {
                points[i3].Y = p2.Y;
                return;
            }
            if (p1.Y == p2.Y)
            {
                points[i3].X = p2.X;
                return;
            }
            int y12 = p2.Y - p1.Y;
            int x12 = p2.X - p1.X;
            double a12 = (double)y12 / (double)x12;
            double a34 = (double)y12 / (double)x12;
            double a23 = -1 / a12;
            double b34 = (double)p3.Y - a34 * (double)p3.X;
            double b23 = (double)p2.Y - a23 * (double)p2.X;
            int x4 = (int)((b23 - b34) / (a34 - a23));
            int y4 = (int)(a23 * (double)x4 + b23);
            points[i3].X = x4;
            points[i3].Y = y4;
        }

        public double GetEdgeLength(MyPoint p1, MyPoint p2)
        {
            return Math.Sqrt(Math.Pow((double)(p1.X - p2.X), 2) + Math.Pow((double)(p1.Y - p2.Y), 2));
        }

        public void SetEdgeLength(MyPoint p1, MyPoint p2, double d)
        {
            double D = Math.Sqrt(Math.Pow((double)(p1.X - p2.X), 2) + Math.Pow((double)(p1.Y - p2.Y), 2));
            double r = d / D;
            double dx = p2.X - p1.X;
            double dy = p2.Y - p1.Y;
            int index = -1;
            if ((index = HasPoint(p2.X, p2.Y)) < 0) return;
            points[index].X = (int)(p1.X + r * dx);
            points[index].Y = (int)(p2.Y - (1 - r) * dy);
        }
    }
}
