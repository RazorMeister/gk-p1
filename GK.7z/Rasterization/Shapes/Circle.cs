﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Rasterization
{
    class Circle : Shape
    {
        public List<MyPoint> center;
        public int r;
        public bool isLocked = false;
        public bool isCenterLocked = false;

        public List<MyPoint> Points 
        { 
            get { return center; }
        }

        public Circle(MyPoint Center, int R = 0)
        {
            if (center == null) center = new List<MyPoint>();
            center.Add(Center);
            r = R;
        }

        public int HasPoint(int x, int y)
        {
            if (center[0].X == x && center[0].Y == y) return 0;
            return -1;
        }

        public bool CanBeRemoved()
        {
            if (center.Count == 0) return true;
            return false;
        }

        public void ChangeRadius(int R)
        {
            if (isLocked) return;
            r = R;
        }

        public void DrawShapes(ref Bitmap bitmap, bool antyaliasing = false)
        {
            if(antyaliasing)
                WuCircle(center[0].X, center[0].Y, r, ref bitmap);
            else
                DrawCircle(center[0].X, center[0].Y, r, ref bitmap);
            Graphics g = Graphics.FromImage(bitmap);
            if (center[0].X - 5 >= 0 && center[0].X - 5 < 800 && center[0].Y - 5 >= 0 && center[0].Y < 800)
            {
                Pen p = new Pen(Color.Pink);
                SolidBrush sb = new SolidBrush(Color.Pink);
                g.DrawEllipse(p, center[0].X - 5, center[0].Y - 5, 11, 11);
                g.FillEllipse(sb, center[0].X - 5, center[0].Y - 5, 11, 11);
            }
        }
        public void DrawCirclePixels(int xc, int yc, int x, int y, ref Bitmap bitmap)
        {
            if(xc + x >= 0 && yc + y >= 0 && xc + x <=799 && yc + y <=799) bitmap.SetPixel(xc + x, yc + y, Color.Black);
            if(xc - x >= 0 && yc + y >= 0 && xc - x <=799 && yc + y <=799) bitmap.SetPixel(xc - x, yc + y, Color.Black);
            if(xc + x >= 0 && yc - y >= 0 && xc + x <=799 && yc - y <=799) bitmap.SetPixel(xc + x, yc - y, Color.Black);
            if(xc - x >= 0 && yc - y >= 0 && xc - x <=799 && yc - y <=799) bitmap.SetPixel(xc - x, yc - y, Color.Black);
            if(xc + y >= 0 && yc + x >= 0 && xc + y <=799 && yc + x <=799) bitmap.SetPixel(xc + y, yc + x, Color.Black);
            if(xc - y >= 0 && yc + x >= 0 && xc - y <=799 && yc + x <=799) bitmap.SetPixel(xc - y, yc + x, Color.Black);
            if(xc + y >= 0 && yc - x >= 0 && xc + y <=799 && yc - x <=799) bitmap.SetPixel(xc + y, yc - x, Color.Black);
            if(xc - y >= 0 && yc - x >= 0 && xc - y <=799 && yc - x <=799) bitmap.SetPixel(xc - y, yc - x, Color.Black);
        }
        public void DrawCircle(int xc, int yc, int r, ref Bitmap bitmap)
        {
            int x = 0, y = r;
            int d = 3 - 2 * r;
            DrawCirclePixels(xc, yc, x, y, ref bitmap);
            while (y >= x)
            {
                x++;
                if (d > 0)
                {
                    y--;
                    d = d + 4 * (x - y) + 10;
                }
                else
                    d = d + 4 * x + 6;
                DrawCirclePixels(xc, yc, x, y, ref bitmap);
            }
        }

        public double DC(int r, int y)
        {
            double x = Math.Sqrt(r * r - y * y);
            return Math.Ceiling(x) - x;
        }
        public void DrawWuPixels(int xc, int yc, int x, int y, double intensity, ref Bitmap bitmap)
        {
            int r = (int)(255 * (1.0 - intensity));
            if (r < 0 || r > 255) return;
            Color color = Color.FromArgb(r, r, r);
            if (xc + x >= 0 && yc + y >= 0 && xc + x <= 799 && yc + y <= 799) bitmap.SetPixel(xc + x, yc + y, color);
            if (xc - x >= 0 && yc + y >= 0 && xc - x <= 799 && yc + y <= 799) bitmap.SetPixel(xc - x, yc + y, color);
            if (xc + x >= 0 && yc - y >= 0 && xc + x <= 799 && yc - y <= 799) bitmap.SetPixel(xc + x, yc - y, color);
            if (xc - x >= 0 && yc - y >= 0 && xc - x <= 799 && yc - y <= 799) bitmap.SetPixel(xc - x, yc - y, color);
            if (xc + y >= 0 && yc + x >= 0 && xc + y <= 799 && yc + x <= 799) bitmap.SetPixel(xc + y, yc + x, color);
            if (xc - y >= 0 && yc + x >= 0 && xc - y <= 799 && yc + x <= 799) bitmap.SetPixel(xc - y, yc + x, color);
            if (xc + y >= 0 && yc - x >= 0 && xc + y <= 799 && yc - x <= 799) bitmap.SetPixel(xc + y, yc - x, color);
            if (xc - y >= 0 && yc - x >= 0 && xc - y <= 799 && yc - x <= 799) bitmap.SetPixel(xc - y, yc - x, color);
        }
        public void WuCircle(int xc, int yc, int R, ref Bitmap bitmap)
        {
            int x = R;
            int y = 0;
            double T = 0;
            DrawWuPixels(xc, yc, x, y, 1.0, ref bitmap);
            while (x > y)
            {
                y++;
                if (DC(R, y) < T)
                    x--;
                DrawWuPixels(xc, yc, x, y, 1 - DC(R, y), ref bitmap);
                DrawWuPixels(xc, yc, x - 1, y, DC(R, y), ref bitmap);
                T = DC(R, y);
            }
        }

        public void SelectPoint(int index, ref Bitmap bitmap, ref PictureBox app)
        {
            Graphics g = Graphics.FromImage(bitmap);
            Pen p = new Pen(Color.DeepPink);
            SolidBrush sb = new SolidBrush(Color.DeepPink);
            if (center[0].X - 5 >= 0 && center[0].X - 5 < 800 && center[0].Y - 5 >= 0 && center[0].Y < 800)
            {
                g.DrawEllipse(p, center[0].X - 5, center[0].Y - 5, 11, 11);
                g.FillEllipse(sb, center[0].X - 5, center[0].Y - 5, 11, 11);
            }
            app.Invalidate();
        }

        public bool CanSelect(int index, MyPoint p)
        {
            return false;
        }

        public MyPoint MoveOnePoint(int x, int y, MyPoint p)
        {
            if (isCenterLocked) return center[0];
            center[0].X += x;
            center[0].Y += y;
            return center[0];
        }

        public void SetCenter(MyPoint p)
        {
            center[0].X = p.X;
            center[0].Y = p.Y;
        }

        public void MakeTangent(MyPoint p1, MyPoint p2)
        {
            double A = (double)(p2.Y - p1.Y);
            double B = -(double)(p2.X - p1.X);
            double C = (double)(-p1.X * (p2.Y - p1.Y) + p1.Y * (p2.X - p1.X));
            double d = Math.Abs(A * center[0].X + B * center[0].Y + C) / Math.Sqrt(Math.Pow(A, 2) + Math.Pow(B, 2));
            if(!isLocked)
            {
                r = (int)d;
                return;
            }
            
            if(isLocked)
            {
                double R = (double)r / (double)d;
                if (p2.X == p1.X)
                {
                    center[0].X -= ((int)d-r);
                    return;
                }
                if (p2.Y == p1.Y)
                {
                    center[0].Y += ((int)d - r);
                    return;
                }
                
                double b2 = (double)center[0].Y + ((double)(p2.X - p1.X)) / ((double)(p2.Y - p1.Y)) * (double)center[0].X;
                double a2 = -((double)(p2.X - p1.X)) / ((double)(p2.Y - p1.Y));
                double a1 = ((double)(p2.Y - p1.Y)) / ((double)(p2.X - p1.X));
                double b1 = (double)p1.Y - (double)a1 * (double)p1.X;
                double x = (b1 - b2) / (a2 - a1);
                double y = a1 * x + b1;
                center[0].X = (int)((center[0].X - x)*R + x);
                center[0].Y = (int)((center[0].Y - y)*R + y);
            }
        }
        void MidpointCircle_1(int R, ref Bitmap bitmap)
        {
            int d = 1 - R;
            int x = 0;
            int y = R;
            bitmap.SetPixel(x,y, Color.Black);
            while (y > x)
            {
                if (d < 0) //Select E
                {
                    d += 2 * x + 3;
                }
                else //Select SE
                {
                    d += 2 * x - 2 * y + 5;
                    y--;
                }
                x++;
                bitmap.SetPixel(x, y, Color.Black);
            }
        }
    }
}
