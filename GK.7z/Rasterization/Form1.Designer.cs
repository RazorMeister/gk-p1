﻿
namespace Rasterization
{
    partial class App
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.MyCanvas = new System.Windows.Forms.PictureBox();
            this.AntyaliasingButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TangentLine = new System.Windows.Forms.Button();
            this.SetCenter = new System.Windows.Forms.Button();
            this.EqualEdges = new System.Windows.Forms.Button();
            this.Set = new System.Windows.Forms.Button();
            this.SetEdges = new System.Windows.Forms.Button();
            this.ParallelEdges = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MyCanvas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.MyCanvas);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.Snow;
            this.splitContainer1.Panel2.Controls.Add(this.AntyaliasingButton);
            this.splitContainer1.Panel2.Controls.Add(this.label6);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox9);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox8);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox7);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox4);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox5);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox6);
            this.splitContainer1.Panel2.Controls.Add(this.textBox1);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox3);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox2);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox1);
            this.splitContainer1.Panel2.Controls.Add(this.TangentLine);
            this.splitContainer1.Panel2.Controls.Add(this.SetCenter);
            this.splitContainer1.Panel2.Controls.Add(this.EqualEdges);
            this.splitContainer1.Panel2.Controls.Add(this.Set);
            this.splitContainer1.Panel2.Controls.Add(this.SetEdges);
            this.splitContainer1.Panel2.Controls.Add(this.ParallelEdges);
            this.splitContainer1.Size = new System.Drawing.Size(1082, 800);
            this.splitContainer1.SplitterDistance = 800;
            this.splitContainer1.TabIndex = 0;
            // 
            // MyCanvas
            // 
            this.MyCanvas.BackColor = System.Drawing.Color.White;
            this.MyCanvas.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MyCanvas.Location = new System.Drawing.Point(0, 0);
            this.MyCanvas.Name = "MyCanvas";
            this.MyCanvas.Size = new System.Drawing.Size(800, 800);
            this.MyCanvas.TabIndex = 0;
            this.MyCanvas.TabStop = false;
            this.MyCanvas.Click += new System.EventHandler(this.MyCanvas_Click);
            this.MyCanvas.DoubleClick += new System.EventHandler(this.MyCanvas_DoubleClick);
            this.MyCanvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MyCanvas_MouseDown);
            this.MyCanvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MyCanvas_MouseMove);
            this.MyCanvas.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MyCanvas_MouseUp);
            // 
            // AntyaliasingButton
            // 
            this.AntyaliasingButton.BackColor = System.Drawing.Color.MistyRose;
            this.AntyaliasingButton.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.AntyaliasingButton.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AntyaliasingButton.Location = new System.Drawing.Point(3, 339);
            this.AntyaliasingButton.Name = "AntyaliasingButton";
            this.AntyaliasingButton.Size = new System.Drawing.Size(273, 50);
            this.AntyaliasingButton.TabIndex = 20;
            this.AntyaliasingButton.Text = "Antialiasing is off";
            this.AntyaliasingButton.UseVisualStyleBackColor = false;
            this.AntyaliasingButton.Click += new System.EventHandler(this.AntyaliasingButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(102, 749);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 23);
            this.label6.TabIndex = 19;
            this.label6.Text = "Tangent Line (T)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.DarkViolet;
            this.pictureBox9.Location = new System.Drawing.Point(3, 729);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(60, 60);
            this.pictureBox9.TabIndex = 18;
            this.pictureBox9.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(105, 680);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 23);
            this.label5.TabIndex = 17;
            this.label5.Text = "Fixed Length (L)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(110, 618);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 23);
            this.label4.TabIndex = 16;
            this.label4.Text = "Fixed Ratio (R)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(102, 550);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 23);
            this.label3.TabIndex = 15;
            this.label3.Text = "Fixed Center (C)";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(102, 485);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 23);
            this.label2.TabIndex = 14;
            this.label2.Text = "Equal Length (E)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(97, 419);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 23);
            this.label1.TabIndex = 13;
            this.label1.Text = "Parallel Edges (P)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Thistle;
            this.pictureBox8.Location = new System.Drawing.Point(3, 663);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(60, 60);
            this.pictureBox8.TabIndex = 11;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.PaleVioletRed;
            this.pictureBox7.Location = new System.Drawing.Point(3, 597);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(60, 60);
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Violet;
            this.pictureBox4.Location = new System.Drawing.Point(3, 531);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 60);
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Indigo;
            this.pictureBox5.Location = new System.Drawing.Point(3, 465);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(60, 60);
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.DarkMagenta;
            this.pictureBox6.Location = new System.Drawing.Point(3, 399);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(60, 60);
            this.pictureBox6.TabIndex = 7;
            this.pictureBox6.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.AcceptsTab = true;
            this.textBox1.Location = new System.Drawing.Point(2, 128);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(214, 27);
            this.textBox1.TabIndex = 2;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox3.Location = new System.Drawing.Point(3, 531);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(60, 60);
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox2.Location = new System.Drawing.Point(3, 465);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 60);
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox1.Location = new System.Drawing.Point(3, 399);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 60);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // TangentLine
            // 
            this.TangentLine.BackColor = System.Drawing.Color.MistyRose;
            this.TangentLine.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TangentLine.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TangentLine.Location = new System.Drawing.Point(2, 283);
            this.TangentLine.Name = "TangentLine";
            this.TangentLine.Size = new System.Drawing.Size(273, 50);
            this.TangentLine.TabIndex = 6;
            this.TangentLine.Text = "Tangent line";
            this.TangentLine.UseVisualStyleBackColor = false;
            this.TangentLine.Click += new System.EventHandler(this.TangentLine_Click);
            // 
            // SetCenter
            // 
            this.SetCenter.BackColor = System.Drawing.Color.MistyRose;
            this.SetCenter.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.SetCenter.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetCenter.Location = new System.Drawing.Point(2, 227);
            this.SetCenter.Name = "SetCenter";
            this.SetCenter.Size = new System.Drawing.Size(273, 50);
            this.SetCenter.TabIndex = 5;
            this.SetCenter.Text = "Fix circle center";
            this.SetCenter.UseVisualStyleBackColor = false;
            this.SetCenter.Click += new System.EventHandler(this.SetCenter_Click);
            // 
            // EqualEdges
            // 
            this.EqualEdges.BackColor = System.Drawing.Color.MistyRose;
            this.EqualEdges.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.EqualEdges.Location = new System.Drawing.Point(2, 171);
            this.EqualEdges.Name = "EqualEdges";
            this.EqualEdges.Size = new System.Drawing.Size(273, 50);
            this.EqualEdges.TabIndex = 4;
            this.EqualEdges.Text = "Equal length";
            this.EqualEdges.UseVisualStyleBackColor = false;
            this.EqualEdges.Click += new System.EventHandler(this.EqualEdges_Click);
            // 
            // Set
            // 
            this.Set.BackColor = System.Drawing.Color.MistyRose;
            this.Set.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Set.Location = new System.Drawing.Point(223, 115);
            this.Set.Name = "Set";
            this.Set.Size = new System.Drawing.Size(53, 50);
            this.Set.TabIndex = 3;
            this.Set.Text = "Set";
            this.Set.UseVisualStyleBackColor = false;
            this.Set.Click += new System.EventHandler(this.Set_Click);
            // 
            // SetEdges
            // 
            this.SetEdges.BackColor = System.Drawing.Color.MistyRose;
            this.SetEdges.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SetEdges.Location = new System.Drawing.Point(3, 59);
            this.SetEdges.Name = "SetEdges";
            this.SetEdges.Size = new System.Drawing.Size(273, 50);
            this.SetEdges.TabIndex = 1;
            this.SetEdges.Text = "Get length/radius";
            this.SetEdges.UseVisualStyleBackColor = false;
            this.SetEdges.Click += new System.EventHandler(this.Get_Click);
            // 
            // ParallelEdges
            // 
            this.ParallelEdges.BackColor = System.Drawing.Color.MistyRose;
            this.ParallelEdges.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.ParallelEdges.Font = new System.Drawing.Font("Leelawadee UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ParallelEdges.Location = new System.Drawing.Point(2, 3);
            this.ParallelEdges.Name = "ParallelEdges";
            this.ParallelEdges.Size = new System.Drawing.Size(273, 50);
            this.ParallelEdges.TabIndex = 0;
            this.ParallelEdges.TabStop = false;
            this.ParallelEdges.Text = "Parallel edges";
            this.ParallelEdges.UseVisualStyleBackColor = false;
            this.ParallelEdges.Click += new System.EventHandler(this.ParallelEdges_Click);
            // 
            // App
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1082, 800);
            this.Controls.Add(this.splitContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "App";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Polygon editor";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.App_KeyDown_1);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.MyCanvas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.PictureBox MyCanvas;
        private System.Windows.Forms.Button ParallelEdges;
        private System.Windows.Forms.Button SetEdges;
        private System.Windows.Forms.Button Set;
        private System.Windows.Forms.Button EqualEdges;
        private System.Windows.Forms.Button SetCenter;
        private System.Windows.Forms.Button TangentLine;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Button AntyaliasingButton;
    }
}

