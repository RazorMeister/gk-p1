﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization
{
    class FixedRatioRelation : Relation
    {
        public List<MyPoint> points;
        public Circle C;
        public Rectangle[] rectangle;
        public int id;
        public List<MyPoint> Points => points;
        public Rectangle[] Rectangle { get => rectangle; set => rectangle = value; }
        public FixedRatioRelation(Circle c, int counter)
        {
            points = new List<MyPoint>() { c.center[0] };
            C = c;
            C.isLocked = true;
            rectangle = new Rectangle[1] { new Rectangle(C.center[0].X - 5, C.center[0].Y - 5 - C.r, 11, 11) };
            id = counter;
        }
        public bool ForceUpdate()
        {
            bool hasChanged = false;
            if (rectangle[0].X != C.center[0].X - 5 || rectangle[0].Y != C.center[0].Y - 5 - C.r)
                hasChanged = true;
            rectangle[0].X = C.center[0].X - 5;
            rectangle[0].Y = C.center[0].Y - 5 - C.r;
            return hasChanged;
        }
    }
}
