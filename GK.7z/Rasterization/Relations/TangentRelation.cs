﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization
{
    class TangentRelation : Relation
    {
        public List<MyPoint> points;
        public Circle C;
        public Rectangle[] rectangle;
        public int id;
        public List<MyPoint> Points => points;
        public Rectangle[] Rectangle { get => rectangle; set => rectangle = value; }
        public TangentRelation(Circle c, MyPoint p1, MyPoint p2, int counter)
        {
            points = new List<MyPoint>() { p1, p2, c.Points[0]};
            C = c;
            rectangle = new Rectangle[2] { new Rectangle((p1.X + p2.X) / 2 - 5, (p1.Y + p2.Y) / 2 - 5, 11, 11), new Rectangle(C.center[0].X - 5 - C.r, C.center[0].Y - 5, 11, 11) };
            id = counter;
        }

        public bool ForceUpdate()
        {
            bool hasChanged = false;
            C.MakeTangent(points[0], points[1]);
            if (rectangle[0].X != (points[0].X + points[1].X) / 2 - 5 || rectangle[0].Y != (points[0].Y + points[1].Y) / 2 - 5 || rectangle[1].X != C.center[0].X - 5 - C.r || rectangle[1].Y != C.center[0].Y - 5)
                hasChanged = true;
            rectangle[0].X = (points[0].X + points[1].X) / 2 - 5;
            rectangle[0].Y = (points[0].Y + points[1].Y) / 2 - 5;
            rectangle[1].X = C.center[0].X - 5 - C.r;
            rectangle[1].Y = C.center[0].Y - 5;
            return hasChanged;
        }
    }
}
