﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization.Relations
{
    class PerpendicularEdgesRelation : Relation
    {
        public List<MyPoint> points;
        Polygon P1;
        Polygon P2;
        public Rectangle[] rectangle;
        public int id;
        public Rectangle[] Rectangle { get => rectangle; set => rectangle = value; }
        public List<MyPoint> Points => points;
        bool sharedVertex = false;

        public PerpendicularEdgesRelation(Polygon pol1, Polygon pol2, MyPoint p1, MyPoint p2, MyPoint p3, MyPoint p4, int counter)
        {
            if(p2 == p4)
            {
                sharedVertex = true;
            }
            points = new List<MyPoint>() { p1, p2, p3, p4 };
            P1 = pol1;
            P2 = pol2;
            rectangle = new Rectangle[2] { new Rectangle((p1.X + p2.X) / 2 - 5, (p1.Y + p2.Y) / 2 - 5, 11, 11), new Rectangle((p3.X + p4.X) / 2 - 5, (p3.Y + p4.Y) / 2 - 5, 11, 11) };
            id = counter;
        }
        public bool ForceUpdate()
        {
            bool hasChanged = false;
            if (sharedVertex)
            {
                if(P1.lastMoved != points[2])
                    P1.SetPerpendicularShared(points[0], points[1], points[2]);
                else
                    P1.SetPerpendicularShared(points[2], points[1], points[0]);
            }
            else
            {
                if (P2.lastMoved != new MyPoint(-1, -1) && P2.lastMoved == points[2])
                {
                    P1.SetPerpendicular(points[2], points[3], points[0], points[1]);
                }
                else if (P2.lastMoved != new MyPoint(-1, -1) && P2.lastMoved == points[3])
                {
                    P1.SetPerpendicular(points[3], points[2], points[1], points[0]);
                }
                else if (P1.lastMoved != new MyPoint(-1, -1) && P1.lastMoved == points[1])
                {
                    P2.SetPerpendicular(points[1], points[0], points[3], points[2]);
                }
                else
                {
                    P2.SetPerpendicular(points[0], points[1], points[2], points[3]);
                }
            }
            
            if (rectangle[0].X != (points[0].X + points[1].X) / 2 - 5 || rectangle[0].Y != (points[0].Y + points[1].Y) / 2 - 5 || rectangle[1].X != (points[2].X + points[3].X) / 2 - 5 || rectangle[1].Y != (points[2].Y + points[3].Y) / 2 - 5)
                hasChanged = true;
            rectangle[0].X = (points[0].X + points[1].X) / 2 - 5;
            rectangle[0].Y = (points[0].Y + points[1].Y) / 2 - 5;
            rectangle[1].X = (points[2].X + points[3].X) / 2 - 5;
            rectangle[1].Y = (points[2].Y + points[3].Y) / 2 - 5;
            return hasChanged;
        }
    }
}
