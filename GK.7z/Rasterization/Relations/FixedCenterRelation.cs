﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization
{
    class FixedCenterRelation : Relation
    {
        public Circle c;
        public List<MyPoint> center;
        public Rectangle[] rectangle;
        public int id;
        public List<MyPoint> points;
        public List<MyPoint> Points => points;
        public Rectangle[] Rectangle { get => rectangle; set => rectangle = value; }
        public FixedCenterRelation(Circle C, MyPoint Center, int counter)
        {
            points = new List<MyPoint>() { Center };
            c = C;
            c.isCenterLocked = true;
            center = new List<MyPoint>() { Center };
            rectangle = new Rectangle[1] { new Rectangle(C.center[0].X - 5, C.center[0].Y - 5 + c.r, 11, 11) };
            id = counter;
        }
        public bool ForceUpdate()
        {
            bool hasChanged = false;
            c.SetCenter(center[0]);
            if (rectangle[0].X != c.center[0].X - 5 || rectangle[0].Y != c.center[0].Y - 5 + c.r)
                hasChanged = true;
            rectangle[0].X = c.center[0].X - 5;
            rectangle[0].Y = c.center[0].Y - 5 + c.r;
            return hasChanged;
        }
    }
}
