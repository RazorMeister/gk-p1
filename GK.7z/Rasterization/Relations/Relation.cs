﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization
{
    
    interface Relation
    {
        public Rectangle[] Rectangle { get; set; }
        public List<MyPoint> Points { get; }
        public bool ForceUpdate();
    }
}
