﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization
{
    class ParallelEdgesRelation: Relation
    {
        public List<MyPoint> points;
        Polygon P1;
        Polygon P2;
        public Rectangle[] rectangle;
        public int id;
        public Rectangle[] Rectangle { get => rectangle; set => rectangle=value; }
        public List<MyPoint> Points => points;
        public ParallelEdgesRelation(Polygon pol1, Polygon pol2, MyPoint p1, MyPoint p2, MyPoint p3, MyPoint p4, int counter)
        {
            if (pol1 == pol2)
            {
                pol2.lastMoved = p1;
            }
            else
                pol2.lastMoved = p3;
            pol1.lastMoved = p1;
            id = counter;
            points = new List<MyPoint>() { p1, p2, p3, p4 };
            P1 = pol1;
            P2 = pol2;
            rectangle = new Rectangle[2];
            Rectangle r1 = new Rectangle((p1.X + p2.X) / 2 - 5, (p1.Y + p2.Y) / 2 - 5, 11, 11);
            rectangle[0] = r1;
            Rectangle r2 = new Rectangle((p3.X + p4.X) / 2 - 5, (p3.Y + p4.Y) / 2 - 5, 11, 11);
            rectangle[1] = r2;
            
        }
        public bool ForceUpdate()
        {
            bool hasChanged = false;
            if (P1.lastMoved != new MyPoint(-1,-1) && (P1.lastMoved == points[0]))
                P2.SetParallel(points[0], points[1], points[2], points[3]);
            else if (P1.lastMoved != new MyPoint(-1, -1) && (P1.lastMoved == points[1]))
                P2.SetParallel(points[1], points[0], points[3], points[2]);
            else if (P2.lastMoved != new MyPoint(-1, -1) && (P2.lastMoved == points[2]))
                P1.SetParallel(points[2], points[3], points[1], points[0]);
            else
                P1.SetParallel(points[3], points[2], points[0], points[1]);
            if (rectangle[0].X != (points[0].X + points[1].X) / 2 - 5 || rectangle[0].Y != (points[0].Y + points[1].Y) / 2 - 5 || rectangle[1].X != (points[2].X + points[3].X) / 2 - 5 || rectangle[1].Y != (points[2].Y + points[3].Y) / 2 - 5)
                hasChanged = true;
            rectangle[0].X = (points[0].X + points[1].X) / 2 - 5;
            rectangle[0].Y = (points[0].Y + points[1].Y) / 2 - 5;
            rectangle[1].X = (points[2].X + points[3].X) / 2 - 5;
            rectangle[1].Y = (points[2].Y + points[3].Y) / 2 - 5;
            return hasChanged;
        }
    }
}
