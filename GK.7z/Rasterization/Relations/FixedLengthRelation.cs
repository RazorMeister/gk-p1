﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Rasterization
{
    class FixedLengthRelation : Relation
    {
        public Polygon p;
        public Rectangle[] rectangle;
        double d;
        public int id;
        public List<MyPoint> points;
        public List<MyPoint> Points => points;
        public Rectangle[] Rectangle { get => rectangle; set => rectangle = value; }
        public FixedLengthRelation(Polygon P, MyPoint P1, MyPoint P2, double D, int counter)
        {
            points = new List<MyPoint>() { P1, P2 };
            p = P;
            d = D;
            rectangle = new Rectangle[1] { new Rectangle((P1.X + P2.X) / 2 - 5, (P1.Y + P2.Y) / 2 - 5, 11, 11) };
            id = counter;
        }
        public bool ForceUpdate()
        {
            bool hasChanged = false;
            if(p.lastMoved == points[0])
                p.SetEdgeLength(points[0], points[1], d);
            else
                p.SetEdgeLength(points[1], points[0], d);
            if (rectangle[0].X != (points[0].X + points[1].X) / 2 - 5 || rectangle[0].Y != (points[0].Y + points[1].Y) / 2 - 5)
                hasChanged = true;
            rectangle[0].X = (points[0].X + points[1].X) / 2 - 5;
            rectangle[0].Y = (points[0].Y + points[1].Y) / 2 - 5;
            return hasChanged;
        }
    }
}
